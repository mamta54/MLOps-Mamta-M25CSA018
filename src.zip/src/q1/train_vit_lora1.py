import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from transformers import ViTForImageClassification
from peft import LoraConfig, get_peft_model
import wandb
from tqdm import tqdm
import os

# ================= WANDB AUTO MODE =================
try:
    wandb.login()
    print("✅ WandB Online Mode")
except:
    os.environ["WANDB_MODE"] = "offline"
    print("⚠️ WandB Offline Mode")

torch.backends.cudnn.benchmark = True

# ---------------- CONFIG ----------------
BATCH_SIZE = 8
EPOCHS = 10
LR = 3e-4
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

RANKS = [4, 8]
ALPHAS = [2,4]
DROPOUT = 0.1

# ---------------- DATA ----------------
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

train_dataset = datasets.CIFAR100(root='./data', train=True, download=True, transform=transform)
val_dataset = datasets.CIFAR100(root='./data', train=False, download=True, transform=transform)

# 🔥 reduce dataset for speed
train_dataset = torch.utils.data.Subset(train_dataset, range(10000))
val_dataset = torch.utils.data.Subset(val_dataset, range(2000))

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=2)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, num_workers=2)

# ---------------- TRAIN ----------------
def train(model, optimizer, criterion):
    model.train()
    total_loss, correct, total = 0, 0, 0

    loop = tqdm(train_loader, desc="Training", leave=False)

    for images, labels in loop:
        images, labels = images.to(DEVICE), labels.to(DEVICE)

        outputs = model(images).logits
        loss = criterion(outputs, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        preds = outputs.argmax(1)
        correct += (preds == labels).sum().item()
        total += labels.size(0)

        loop.set_postfix(loss=loss.item(), acc=correct/total)

    return total_loss / len(train_loader), correct / total


# ---------------- VALIDATION ----------------
def validate(model, criterion):
    model.eval()
    total_loss, correct, total = 0, 0, 0

    loop = tqdm(val_loader, desc="Validation", leave=False)

    with torch.no_grad():
        for images, labels in loop:
            images, labels = images.to(DEVICE), labels.to(DEVICE)

            outputs = model(images).logits
            loss = criterion(outputs, labels)

            total_loss += loss.item()
            preds = outputs.argmax(1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

            loop.set_postfix(loss=loss.item(), acc=correct/total)

    return total_loss / len(val_loader), correct / total


# ================= MAIN LOOP =================
for r in RANKS:
    for a in ALPHAS:

        print(f"\n\n🔥 Running Experiment: Rank={r}, Alpha={a}")

        wandb.init(
            project="Assignment5_Q1_ViT_LoRA",
            name=f"Rank{r}_Alpha{a}",
            reinit=True,
            config={
                "rank": r,
                "alpha": a,
                "dropout": DROPOUT
            }
        )

        # ---------------- MODEL ----------------
        model = ViTForImageClassification.from_pretrained(
            "google/vit-base-patch16-224",
            num_labels=100,
            ignore_mismatched_sizes=True
        )

        # 🔥 Freeze backbone
        for param in model.vit.parameters():
            param.requires_grad = False

        lora_config = LoraConfig(
            r=r,
            lora_alpha=a,
            target_modules=["query", "key", "value"],
            lora_dropout=DROPOUT,
            bias="none"
        )

        model = get_peft_model(model, lora_config)
        model.to(DEVICE)

        # ---------------- PARAM COUNT ----------------
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

        print(f"Total Params: {total_params}")
        print(f"Trainable Params: {trainable_params}")
        print(f"Trainable %: {100 * trainable_params / total_params:.4f}%")

        # ---------------- LOSS & OPTIMIZER ----------------
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters(), lr=LR)

        # ---------------- TRAIN LOOP ----------------
        for epoch in range(EPOCHS):
            print(f"\n========== Rank={r}, Alpha={a} | Epoch {epoch+1}/{EPOCHS} ==========")

            train_loss, train_acc = train(model, optimizer, criterion)
            val_loss, val_acc = validate(model, criterion)

            print("\n----- Epoch Summary -----")
            print(f"Experiment: Rank={r}, Alpha={a}")
            print(f"Train Loss: {train_loss:.4f}")
            print(f"Train Accuracy: {train_acc*100:.2f}%")
            print(f"Validation Loss: {val_loss:.4f}")
            print(f"Validation Accuracy: {val_acc*100:.2f}%")
            print("-------------------------\n")

            wandb.log({
                "epoch": epoch + 1,
                "rank": r,
                "alpha": a,
                "train_loss": train_loss,
                "train_acc": train_acc,
                "val_loss": val_loss,
                "val_acc": val_acc
            })

        # ---------------- SAVE ----------------
        torch.save(model.state_dict(), f"models/lora_r{r}_a{a}.pth")

        wandb.finish()