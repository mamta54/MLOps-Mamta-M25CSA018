import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from transformers import ViTForImageClassification
from peft import LoraConfig, get_peft_model
import wandb
from tqdm import tqdm

# ---------------- CONFIG ----------------
BATCH_SIZE = 16
EPOCHS = 5   # keep small for now
LR = 3e-4
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# 🔥 CHANGE THESE FOR EXPERIMENTS
RANK = 4
ALPHA = 4
DROPOUT = 0.1

wandb.init(project="Assignment5_Q1_ViT_LoRA", config={
    "rank": RANK,
    "alpha": ALPHA,
    "dropout": DROPOUT
})

# ---------------- DATA ----------------
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

train_dataset = datasets.CIFAR100(root='./data', train=True, download=True, transform=transform)
val_dataset = datasets.CIFAR100(root='./data', train=False, download=True, transform=transform)

# 🔥 subset for speed
train_dataset = torch.utils.data.Subset(train_dataset, range(15000))
val_dataset = torch.utils.data.Subset(val_dataset, range(3000))

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE)

# ---------------- MODEL ----------------
model = ViTForImageClassification.from_pretrained(
    "google/vit-base-patch16-224",
    num_labels=100,
    ignore_mismatched_sizes=True
)

# 🔥 LoRA CONFIG
lora_config = LoraConfig(
    r=RANK,
    lora_alpha=ALPHA,
    target_modules=["query", "key", "value"],  # Q,K,V
    lora_dropout=DROPOUT,
    bias="none"
)

model = get_peft_model(model, lora_config)
model.to(DEVICE)

# ---------------- PARAM COUNT ----------------
total_params = sum(p.numel() for p in model.parameters())
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

print(f"Total Params: {total_params}")
print(f"Trainable Params: {trainable_params}")

# ---------------- LOSS & OPTIMIZER ----------------
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=LR)

# ---------------- TRAIN ----------------
def train():
    model.train()
    total_loss, correct, total = 0, 0, 0

    loop = tqdm(train_loader, leave=False)

    for images, labels in loop:
        images, labels = images.to(DEVICE), labels.to(DEVICE)

        outputs = model(images).logits
        loss = criterion(outputs, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        preds = outputs.argmax(1)
        correct += (preds == labels).sum().item()
        total += labels.size(0)

        loop.set_postfix(loss=loss.item(), acc=correct/total)

    return total_loss / len(train_loader), correct / total

# ---------------- VALIDATE ----------------
def validate():
    model.eval()
    total_loss, correct, total = 0, 0, 0

    with torch.no_grad():
        for images, labels in val_loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)

            outputs = model(images).logits
            loss = criterion(outputs, labels)

            total_loss += loss.item()
            preds = outputs.argmax(1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

    return total_loss / len(val_loader), correct / total

# ---------------- LOOP ----------------
for epoch in range(EPOCHS):
    print(f"\nEpoch {epoch+1}")

    train_loss, train_acc = train()
    val_loss, val_acc = validate()

    print(f"Train Acc: {train_acc*100:.2f}%")
    print(f"Val Acc: {val_acc*100:.2f}%")

    wandb.log({
        "epoch": epoch,
        "train_acc": train_acc,
        "val_acc": val_acc
    })

# ---------------- SAVE ----------------
torch.save(model.state_dict(), f"models/lora_r{RANK}_a{ALPHA}.pth")
