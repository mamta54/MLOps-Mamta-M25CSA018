import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from transformers import ViTForImageClassification
import wandb
from tqdm import tqdm
from torch.cuda.amp import autocast, GradScaler

torch.backends.cudnn.benchmark = True

# ---------------- CONFIG ----------------
BATCH_SIZE = 16
EPOCHS = 10
LR = 3e-4
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# ---------------- WANDB ----------------
wandb.init(project="Assignment5_Q1_ViT_Baseline")

# ---------------- DATA ----------------
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

train_dataset = datasets.CIFAR100(root='./data', train=True, download=True, transform=transform)
val_dataset = datasets.CIFAR100(root='./data', train=False, download=True, transform=transform)

# 🔥 Subset (for speed)
train_dataset = torch.utils.data.Subset(train_dataset, range(15000))
val_dataset = torch.utils.data.Subset(val_dataset, range(3000))

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE)

# ---------------- MODEL ----------------
model = ViTForImageClassification.from_pretrained(
    "google/vit-base-patch16-224",
    num_labels=100,
    ignore_mismatched_sizes=True
)

model.to(DEVICE)

# 🔥 Freeze backbone
for param in model.vit.parameters():
    param.requires_grad = False

# 🔥 Train only classifier
for param in model.classifier.parameters():
    param.requires_grad = True

# ---------------- LOSS & OPTIMIZER ----------------
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=LR)
scaler = GradScaler()

# ---------------- TRAIN FUNCTION ----------------
def train():
    model.train()
    total_loss, correct, total = 0, 0, 0

    loop = tqdm(train_loader, desc="Training", leave=False)

    for images, labels in loop:
        images, labels = images.to(DEVICE), labels.to(DEVICE)

        with autocast():
            outputs = model(images).logits
            loss = criterion(outputs, labels)

        optimizer.zero_grad()
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        total_loss += loss.item()
        preds = outputs.argmax(1)
        correct += (preds == labels).sum().item()
        total += labels.size(0)

        loop.set_postfix(loss=loss.item(), acc=correct/total)

    return total_loss / len(train_loader), correct / total


# ---------------- VALIDATION ----------------
def validate():
    model.eval()
    total_loss, correct, total = 0, 0, 0

    loop = tqdm(val_loader, desc="Validation", leave=False)

    with torch.no_grad():
        for images, labels in loop:
            images, labels = images.to(DEVICE), labels.to(DEVICE)

            with autocast():
                outputs = model(images).logits
                loss = criterion(outputs, labels)

            total_loss += loss.item()
            preds = outputs.argmax(1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

            loop.set_postfix(loss=loss.item(), acc=correct/total)

    return total_loss / len(val_loader), correct / total


# ---------------- TRAIN LOOP ----------------
for epoch in range(EPOCHS):
    print(f"\n========== Epoch {epoch+1}/{EPOCHS} ==========")

    train_loss, train_acc = train()
    val_loss, val_acc = validate()

    print("\n----- Epoch Summary -----")
    print(f"Epoch: {epoch+1}/{EPOCHS}")
    print(f"Train Loss: {train_loss:.4f}")
    print(f"Train Accuracy: {train_acc:.4f}")
    print(f"Validation Loss: {val_loss:.4f}")
    print(f"Validation Accuracy: {val_acc:.4f}")
    print("-------------------------\n")

    wandb.log({
        "epoch": epoch + 1,
        "train_loss": train_loss,
        "train_acc": train_acc,
        "val_loss": val_loss,
        "val_acc": val_acc
    })

# ---------------- SAVE MODEL ----------------
torch.save(model.state_dict(), "models/vit_baseline.pth")